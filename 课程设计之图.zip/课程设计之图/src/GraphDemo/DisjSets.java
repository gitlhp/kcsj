package GraphDemo;  
  
class DisjSets{  
    public int s[];  
    public DisjSets(int numElements){  
        s=new int[numElements];  
        for(int i=0;i<s.length;i++)  
            s[i]=i;  
    }  
    public void union(int root1,int root2){  
        int x,y;  
        x=find(root1);  
        y=find(root2);  
        if(x!=y) s[y]=x;  
    }  
    public int find(int x){  
        while(x!=s[x])  
            x=s[x];  
        return x;  
    }  
}  