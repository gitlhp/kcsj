package GraphDemo;  
  
//import TwoWayLinkedListDemo.TwoWayLinkedListNode;  
  
public class Arc{  
    int vex;  
    int adjVex;  
    public Arc nextArc;  
    int weight;  
    public Arc(){}  
    public Arc(int adjVex,Arc nextArc,int weight){  
        this.adjVex=adjVex;  
        this.nextArc=nextArc;  
        this.weight=weight;  
    }  
    public Arc(int adjVex,int weight){  
        this(adjVex,null,weight);  
    }  
    public Arc(int adjVex,Arc nextArc){  
        this(adjVex,nextArc,1);  
    }  
    public Arc(int adjVex){  
        this(adjVex,null,1);  
    }  
} 