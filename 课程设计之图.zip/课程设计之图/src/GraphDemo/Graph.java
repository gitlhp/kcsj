package GraphDemo;  
  
import java.util.ArrayList;  
import java.util.Comparator;  
import java.util.HashMap;  
import java.util.LinkedList;  
import java.util.List;  
import java.util.Map;  
import java.util.PriorityQueue;  
import java.util.Queue;  
import java.util.Scanner;  
import java.util.Stack;  
public class Graph<AnyType>{  
    int DG=1,UNG=2,DN=3,UND=4;  
    int vexNum;  
    int arcNum;  
    int type;  
    int count;  
    int INF=0xfffff;  
    Node first;  
    LinkedList<Vertex> vertexs=new LinkedList<Vertex>();  
    public Graph(int type,int vexNum,int arcNum){  
        this.type=type;  
        this.arcNum=arcNum;  
        this.vexNum=vexNum;  
    }  
    //����ͼ  
    public Graph(){}  
    //��������ͼ  
    public void createDG(List<AnyType>v,List<Integer>a,List<Integer> b,List<Integer> x){  
        for(int i=0;i<vexNum;i++)  
            vertexs.add(new Vertex<AnyType>(v.get(i)));  
        for(int i=0;i<a.size();i++){  
            int arc1=a.get(i);  
            int arc2=b.get(i);  
            Vertex<AnyType> ver=vertexs.get(arc1);  
            Arc arc=new Arc(arc2);  
            arc.vex=arc1;  
            arc.weight=x.get(i);  
            arc.nextArc=ver.firstArc;  
            ver.firstArc=arc;  
        }  
    }  
    //��������ͼ  
    public void createUDG(List<AnyType> v,List<Integer> a,List<Integer> b,List<Integer> x){  
        for(int i=0;i<vexNum;i++)  
            vertexs.add(new Vertex<AnyType>(v.get(i)));  
        for(int i=0;i<a.size();i++){  
            int arc1=a.get(i);  
            int arc2=b.get(i);  
            Vertex<AnyType> ver=vertexs.get(arc1);  
            Arc p=new Arc(arc2);  
            p.nextArc=ver.firstArc;  
            ver.firstArc=p;  
            Arc q=new Arc(arc1);  
            ver=vertexs.get(arc2);  
            q.nextArc=ver.firstArc;  
            ver.firstArc=q;  
            q.weight=x.get(i);  
            p.weight=x.get(i);  
        }  
    }  
    //����������  
    public void createDN(List<AnyType> v,List<Integer> a,List<Integer> b,List<Integer> x){  
        for(int i=0;i<vexNum;i++)  
            vertexs.add(new Vertex<AnyType>(v.get(i)));  
        for(int i=0;i<a.size();i++){  
         int arc1=a.get(i);  
         int arc2=b.get(i);   
         int weight=x.get(i);  
         Vertex<AnyType> ver=vertexs.get(arc1);  
         Arc arc=new Arc(arc2,weight);  
         arc.nextArc=ver.firstArc;  
         ver.firstArc=arc;   
        }  
    }  
    //����������  
    public void createUDN(List<AnyType> v,List<Integer> a,List<Integer> b,List<Integer> x){  
        for(int i=0;i<vexNum;i++)      
            vertexs.add(new Vertex<AnyType>(v.get(i)));  
        for(int i=0;i<a.size();i++){  
            int arc1=a.get(i);  
            int arc2=b.get(i);    
         Vertex<AnyType> ver=vertexs.get(arc1);  
         Arc p=new Arc(arc2);  
         p.nextArc=ver.firstArc;  
         ver.firstArc=p;  
         Arc q=new Arc(arc1);  
         ver=vertexs.get(arc2);  
         q.nextArc=ver.firstArc;  
         ver.firstArc=q;  
         q.weight=x.get(i);  
         p.weight=x.get(i);  
        }  
    }  
    public void createGraph(int type,List<AnyType> v,List<Integer> a,List<Integer> b,List<Integer> x){  
        if(vexNum<=0||arcNum<0){  
            System.out.println("��������ͼ����");  
            return;  
        }  
        switch(type){  
        case 1:createDG(v,a,b,x);break;  
        case 2:createUDG(v,a,b,x);break;  
        case 3:createDN(v,a,b,x);break;  
        case 4:createUDN(v,a,b,x);break;  
        default:System.out.println("��ָ����ͼ����������");  
        }  
    }  
    //���һ���ڽӵ�  
    public int firstAdjVex(int v){  
        if(v<0||v>vexNum){  
            System.out.println("���벻�Ϸ���");  
        }  
        Vertex<AnyType> ver=vertexs.get(v);  
        Arc p=ver.firstArc;  
        if(p!=null)return p.adjVex;  
        return -1;  
    }  
    //����һ����  
    public int nextAdjVex(int v,int w){  
        if(v<0||v>=vexNum){  
            System.out.println("���벻�Ϸ���");  
        }  
        Vertex<AnyType> ver=vertexs.get(v);  
        Arc arc=ver.firstArc;  
        int next=arc.adjVex;  
        while(arc!=null&&next!=w){  
            arc=arc.nextArc;  
            next=arc.adjVex;  
        }  
        if(arc!=null)  
            arc=arc.nextArc;  
        if(arc!=null)return arc.adjVex;  
        return -1;  
    }  
    //�����  
    public int outDegree(int v){  
        int outDegree=0;  
        Vertex<AnyType> ver=vertexs.get(v);  
        Arc arc=ver.firstArc;  
        while(arc!=null){  
            outDegree++;  
            arc=arc.nextArc;  
        }  
        return outDegree;  
    }  
    //�����  
    public int inDegree(int v){  
        int inDegree=0;  
        for(int i=0;i<vexNum;i++){  
            if(i==v)continue;  
            Vertex<AnyType> ver=vertexs.get(i);  
            Arc arc=ver.firstArc;  
            while(arc!=null){  
                if(arc.adjVex==v){  
                    inDegree++;  
                    break;  
                }  
                arc=arc.nextArc;  
            }  
        }  
        return inDegree;  
    }  
    //�ڽӱ�ת��Ϊ�ڽӾ���  
    public int[][] getAdjacencyMatrix(){  
        int[][] adjacencyMatrix=new int[vexNum][vexNum];  
        for(int i=0;i<vexNum;i++){  
            Vertex<AnyType> ver=vertexs.get(i);  
            Arc arc=ver.firstArc;  
            for(int j=firstAdjVex(i);j>=0;j=nextAdjVex(i,j)){  
                adjacencyMatrix[i][j]=arc.weight;  
                arc=arc.nextArc;  
            }  
        }  
        return adjacencyMatrix;  
    }  
    //��ӡ�ڽӾ���  
    public void printAdjacencyMatrix(){  
        int[][] adjacencyMatrix=getAdjacencyMatrix();  
        for(int i=0;i<adjacencyMatrix.length;i++)  
        {  
            for(int j=0;j<adjacencyMatrix[i].length;j++)  
                System.out.print(adjacencyMatrix[i][j]+" ");  
            System.out.println();  
        }  
    }  
    //����ڵ�  
    public void insertVertex(AnyType data){  
        vertexs.add(new Vertex<AnyType>(data));  
        vexNum++;  
    }  
    //ɾ���ڵ�  
    public void delete(AnyType a){  
        int i;  
        for(i=0;i<vexNum;i++)  
            if(vertexs.get(i).data.equals(a))  
                break;  
        if(i==vexNum){  
            System.out.println("����ɾ����Ԫ�ز����ڣ�");  
            return;  
        }  
        for(int j=firstAdjVex(i);j>=0;j=nextAdjVex(i,j)){  
            if(type==2||type==4)  
                vertexs.get(j).degree--;  
            else{  
                vertexs.get(j).inDegree--;  
                vertexs.get(j).degree--;  
            }  
        }  
        vertexs.remove(i);  
        vexNum--;  
        for(int j=0;j<vexNum;j++){  
            Vertex<AnyType> v=vertexs.get(j);  
            Arc arc=v.firstArc;  
            if(arc!=null){  
                if(arc.adjVex==i){  
                    v.firstArc=v.firstArc.nextArc;  
                    if(type==2||type==4)  
                        v.degree--;  
                    else{  
                        v.outDegree--;  
                        v.degree--;  
                    }  
                    continue;  
                }  
            while(arc.nextArc!=null){  
                if(arc.nextArc.adjVex==i){  
                    arc.nextArc=arc.nextArc.nextArc;  
                    if(type==2||type==4){  
                        v.degree--;  
                    }  
                    else if(type==1||type==3){  
                        arc=arc.nextArc;  
                        v.outDegree--;  
                        v.degree--;  
                    }  
                    break;  
                }  
                arc=arc.nextArc;  
            }  
        }  
    }  
   }  
    //ɾ����  
    public void removeEdege(int i,int a){  
        Arc q=vertexs.get(i).firstArc;  
        if(q.adjVex==a)  
            vertexs.get(i).firstArc=q.nextArc;  
        while(q.nextArc!=null){  
            if(q.nextArc.adjVex==a){  
                q.nextArc=q.nextArc.nextArc;  
                break;  
            }  
            q=q.nextArc;  
        }  
    }  
    //���ӱ�  
    public void addEdege(int ss[],int ee[],int num){  
        for(int i=0;i<num;i++){  
            Arc tmp1=new Arc();  
            tmp1.adjVex=ee[i];  
            Arc q=vertexs.get(ss[i]).firstArc;  
            tmp1.nextArc=q;  
            vertexs.get(ss[i]).firstArc=tmp1;  
        }  
    }  
    //DFS  
    void DFS(int start){  
        if(start>=vexNum)return;  
        Vertex<AnyType> tmp=vertexs.get(start);  
        tmp.vis=true;  
        System.out.print(tmp.data+" ");  
        if(tmp.firstArc!=null){  
            for(int w=tmp.firstArc.adjVex;w>=0;w=nextAdjVex(start,w)){  
                if(vertexs.get(w).vis==false)  
                    DFS(w);  
            }  
        }  
    }  
    //BFS  
    void BFS(int start){  
        Queue<Integer> queue=new LinkedList<Integer>();  
        vertexs.get(start).vis=true;  
        queue.add(start);  
        while(!queue.isEmpty()){  
            int tmp1=queue.remove();  
            System.out.print(vertexs.get(tmp1).data+" ");  
            int tmp2=firstAdjVex(tmp1);  
            while(tmp2!=-1){  
                if(vertexs.get(tmp2).vis==false){  
                    vertexs.get(tmp2).vis=true;  
                    queue.add(tmp2);  
                }  
                tmp2=nextAdjVex(tmp1,tmp2);  
            }  
        }  
    }  
    //������ȱ�����С������  
    public void DFSTree(int v){  
        first=new Node<AnyType>();  
        first.data=vertexs.get(v).data;  
        DFSTree(v,first);  
    }  
    void DFSTree(int v,Node T){  
        vertexs.get(v).vis=true;  
        int w;  
        Node p;  
        boolean first=true;  
        Node q=null;  
        System.out.print(T.data+" ");  
        for(w=firstAdjVex(v);w>=0;w=nextAdjVex(v,w))  
            if(!vertexs.get(w).vis){  
                p=new Node(vertexs.get(w).data);  
                if(first){  
                    T.firstChild=p;  
                    first=false;  
                }  
                else q.Sibling=p;  
                q=p;  
                DFSTree(w,q);  
            }  
    }  
    //������ȱ�����С������(�������)  
    public void preOrderTree(){  
        if(first!=null)preOrderTree(first);  
    }  
    public void preOrderTree(Node<AnyType> t){  
        if(t!=null){  
            System.out.print(t.data+" ");//������  
            preOrderTree(t.firstChild);//����������  
            preOrderTree(t.Sibling);//����������  
        }  
    }  
    //�ж�����ͼ�Ƿ���ڻ�  
    public boolean isDGCircle(){  
        Queue<Vertex> q=new LinkedList<Vertex>();  
        int count=0;  
        for(int i=0;i<vertexs.size();i++)  
            if(vertexs.get(i).inDegree==0)  
                q.add(vertexs.get(i));  
        while(!q.isEmpty()){  
            Vertex v=q.poll();  
            count++;  
            Arc p=null;  
            for(p=v.firstArc;p!=null;p=p.nextArc)  
                if(--vertexs.get(p.adjVex).inDegree==0)  
                    q.add(vertexs.get(p.adjVex));  
        }  
        if(count!=vexNum)return false;  
        else return true;  
    }  
    //�ж�����ͼ�Ƿ���ڻ�  
    public boolean UDGCircle(){  
        if(arcNum>vexNum-1)  
            return false;  
        else return true;  
    }  
    //BFS�ж��Ƿ����·��  
    public boolean BFSRoute(Graph<AnyType> g,int u,int v){  
        Queue<Integer> queue=new LinkedList<Integer>();  
        g.vertexs.get(u).vis=true;  
        queue.add(u);  
        while(!queue.isEmpty()){  
            int tmp1=queue.remove();  
            if(tmp1==v){  
                for(int i=0;i<g.vertexs.size();i++)  
                    g.vertexs.get(i).vis=false;  
                return true;  
            }  
            int tmp2=firstAdjVex(tmp1);  
            while(tmp2!=-1){  
                if(g.vertexs.get(tmp2).vis==false){  
                    queue.add(tmp2);  
                    g.vertexs.get(tmp2).vis=true;  
                }  
                tmp2=nextAdjVex(tmp1,tmp2);  
            }  
        }  
        for(int i=0;i<g.vertexs.size();i++)  
            g.vertexs.get(i).vis=false;  
        return false;  
    }  
    //�ж�U��V�Ƿ����·��  
    public boolean isURouteV(Graph<AnyType> g,int u,int v){  
        if(BFSRoute(g,u,v)==true)  
            return true;  
        return false;  
    }  
    //��һ����U��V�ļ�·��  
    public LinkedList<Integer> oneURouteV(Graph<AnyType> g,int u,int v){  
        Map<Integer,Integer> parent=new HashMap<Integer,Integer>();  
        LinkedList<Integer> tmp=new LinkedList<Integer>();  
        if(isURouteV(g,u,v)==true){  
            Queue<Integer> queue=new LinkedList<Integer>();  
            for(int i=0;i<g.vertexs.size();i++)  
                parent.put(i,i);  
            g.vertexs.get(u).vis=true;  
            queue.add(u);  
            while(!queue.isEmpty()){  
                int tmp1=queue.remove();  
                if(tmp1==v)break;  
                int tmp2=firstAdjVex(tmp1);  
                while(tmp2!=-1){  
                    if(g.vertexs.get(tmp2).vis==false){  
                        parent.put(tmp2,tmp1);  
                        queue.add(tmp2);  
                        g.vertexs.get(tmp2).vis=true;  
                    }  
                    tmp2=nextAdjVex(tmp1,tmp2);  
                }  
            }  
            //��·��  
            int x=v;  
            while(x!=u){  
                tmp.add(x);  
                x=parent.get(x);  
            }  
            tmp.add(u);  
            return tmp;  
        }  
        else{  
            System.out.println("����֮��û��·����");  
            return null;  
        }  
    }  
    //��U��V������·��  
    public void allURouteV(Graph<AnyType> g,int u,int v){  
        LinkedList<Integer> stack=new LinkedList<Integer>();  
        count=1;  
        stack.addLast(u);  
        for(int i=firstAdjVex(u);i!=-1;i=nextAdjVex(u,i)){  
            if(g.vertexs.get(i).vis==false){  
                g.vertexs.get(i).vis=true;  
                stack.addLast(i);  
                search(g,i,v,stack);  
                g.vertexs.get(i).vis=false;  
                stack.pollLast();  
            }  
        }  
    }  
    public void search(Graph<AnyType> g,int x,int v,LinkedList<Integer> ss){  
        if(x==v){  
            System.out.print("·��"+count+":");  
            count++;  
            for(int i=0;i<ss.size()-1;i++)  
                System.out.print(g.vertexs.get(ss.get(i)).data+"->");  
            System.out.println(g.vertexs.get(ss.get(ss.size()-1)).data);  
            return;  
        }  
        else{  
            for(int j=firstAdjVex(x);j!=-1;j=nextAdjVex(x,j))  
                if(g.vertexs.get(j).vis==false){  
                    g.vertexs.get(j).vis=true;  
                    ss.addLast(j);  
                    search(g,j,v,ss);  
                    g.vertexs.get(j).vis=false;  
                    ss.pollLast();  
                }  
        }  
    }  
    //Dijkstra  
    int pre[]=new int[107];  
    Map<Integer,Integer> parents=new HashMap<Integer,Integer>();  
    public void Dijkstra(Graph<AnyType> g,Vertex<AnyType> s,int start){  
        LinkedList<Integer> tmp=new LinkedList<Integer>();  
        for(int i=0;i<g.vertexs.size();i++){  
            pre[i]=start;  
            g.vertexs.get(i).dist=INF;  
            g.vertexs.get(i).vis=false;  
            parents.put(i,i);  
        }  
        s.dist=0;  
        for(int i=0;i<g.vertexs.size();i++){  
            int min=INF;  
            int v=0;  
            for(int j=0;j<g.vertexs.size();j++)  
                if(g.vertexs.get(j).vis==false&&g.vertexs.get(j).dist<min){  
                    min=g.vertexs.get(j).dist;  
                    v=j;  
                }  
            g.vertexs.get(v).vis=true;  
            for(int j=0;j<g.vertexs.size();j++)  
                if(g.vertexs.get(j).vis==false&&weigthWith(v,j)!=-1){  
                    if(g.vertexs.get(j).dist>g.vertexs.get(v).dist+weigthWith(v,j)){  
                        g.vertexs.get(j).dist=g.vertexs.get(v).dist+weigthWith(v,j);  
                        pre[j]=v;  
                        parents.put(j,v);  
                    }  
                }  
        }  
    }  
    public void printPath(Graph<AnyType>g,int u,int v){  
        int x=v;  
        LinkedList<Integer> tmp=new LinkedList<Integer>();  
        while(x!=u){  
            tmp.add(x);  
            x=parents.get(x);  
        }  
        tmp.add(u);  
        for(int i=tmp.size()-1;i>0;i--)  
            System.out.print(g.vertexs.get(tmp.get(i)).data+"->");  
        System.out.println(g.vertexs.get(tmp.get(0)).data);  
    }  
    public void printPath(int s,int e,int num){  
        int a[]=new int[107],i,k;  
        k=0;  
        a[k++]=e;  
        i=e;  
        while(s!=i){  
            i=pre[i];  
            a[k++]=i;  
        }  
        System.out.print("Path"+num+": ");  
        for(i=k-1;i>0;i--)  
            System.out.print(a[i]+"-->");  
        System.out.println(a[0]);  
    }  
    //�ж�v��w�Ƿ����·������������Ȩֵ  
    public int weigthWith(int v,int w){  
        Arc p=vertexs.get(v).firstArc;  
        if(p==null)return -1;  
        while(p!=null&&p.adjVex!=w)  
            p=p.nextArc;  
        if(p==null)return -1;  
        return p.weight;  
    }  
    //Kruskal  
    public int Kruskal(Graph<AnyType> g){  
        int edgesAccept=0,ans=0;  
        LinkedList<Arc> minTree=new LinkedList<Arc>();  
        PriorityQueue<Arc> pq=new PriorityQueue<Arc>(100,new Comparator<Arc>(){  
            public int compare(Arc a,Arc b){  
                if(a.weight>b.weight)return 1;  
                else return -1;  
            }  
        });  
        for(int i=0;i<g.vertexs.size();i++){  
            Arc p=g.vertexs.get(i).firstArc;  
            while(p!=null){  
                pq.add(p);  
                p=p.nextArc;  
            }  
        }  
        DisjSets ds=new DisjSets(100);  
        Arc edge;  
        int u,v;  
        while(edgesAccept<g.vertexs.size()-1){  
            edge=pq.poll();  
            u=edge.vex;  
            v=edge.adjVex;  
            int uset=ds.find(u);  
            int vset=ds.find(v);  
            if(uset!=vset){  
                edgesAccept++;  
                ds.union(u,v);  
                minTree.add(edge);  
                ans+=edge.weight;  
            }  
        }  
        return ans;  
    }  
    //prime  
    public void prime(Graph<AnyType> g){  
        for(int i=0;i<g.vertexs.size();i++){  
            g.vertexs.get(i).primDist=INF;  
            g.vertexs.get(i).primVis=false;  
        }  
        g.vertexs.get(0).primDist=0;  
        int count=0;  
        for(int i=0;i<g.vertexs.size();i++){  
            int min=INF;  
            int v=0;  
            for(int j=0;j<g.vertexs.size();j++)  
                if(g.vertexs.get(j).primVis==false&&g.vertexs.get(i).primDist<min){  
                    min=g.vertexs.get(i).primDist;  
                    v=j;  
                }  
            g.vertexs.get(v).primVis=true;  
            count+=min;  
            System.out.print(g.vertexs.get(v).data+" ");  
            if(i==g.vertexs.size()-1)  
            {  
                System.out.println("\n��С��������ֵ��:"+count);  
                break;  
            }  
            for(int j=0;j<g.vertexs.size();j++)  
                if(g.vertexs.get(j).primVis==false&&weigthWith(v,j)!=-1)  
                    if(g.vertexs.get(j).primDist>weigthWith(v,j))  
                        g.vertexs.get(j).primDist=weigthWith(v,j);  
        }  
    }  
        public void Floyd(){  
            int[][] adjacencyMartix=getAdjacencyMatrix();  
            for(int i=0;i<adjacencyMartix.length;i++)  
                for(int j=0;j<adjacencyMartix[i].length;j++)  
                    if(adjacencyMartix[i][j]==0)  
                        adjacencyMartix[i][j]=INF;  
            for(int k=0;k<adjacencyMartix.length;k++)  
                for(int i=0;i<adjacencyMartix.length;i++)  
                    for(int j=0;j<adjacencyMartix[i].length;j++)  
                        if(i!=j&&adjacencyMartix[i][k]+adjacencyMartix[k][j]<adjacencyMartix[i][j])  
                            adjacencyMartix[i][j]=adjacencyMartix[i][k]+adjacencyMartix[k][j];  
            for(int i=0;i<adjacencyMartix.length;i++){  
                System.out.print("��"+i+"�����������̾����ǣ�");  
                for(int j=0;j<adjacencyMartix[i].length;j++)  
                    if(adjacencyMartix[i][j]==INF)  
                            System.out.print("������  ");  
                    else System.out.print(adjacencyMartix[i][j]+"  ");  
                System.out.println();  
            }  
    }  
}  