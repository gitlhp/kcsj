package GraphDemo;  
  
public class Node<AnyType>{  
    AnyType data;  
    Node<AnyType> firstChild,Sibling;  
    Node(){  
        data=null;  
        firstChild=Sibling=null;  
    }  
    Node(AnyType data){  
        this.data=data;  
        firstChild=Sibling=null;  
    }  
    Node(AnyType data,Node<AnyType>lt,Node<AnyType>rt){  
        this.data=data;  
        firstChild=lt;  
        Sibling=rt;  
    }  
    public Node<AnyType>getleftChild(){  
        return firstChild;  
    }  
    public Node<AnyType>getrigthChild(){  
        return Sibling;  
    }  
}