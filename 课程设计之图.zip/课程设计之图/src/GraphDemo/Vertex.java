package GraphDemo;  
  
public class Vertex<AnyType>{  
    public AnyType data;  
    public Arc firstArc;  
    public boolean vis;  
    public boolean primVis;  
    public int inDegree;  
    public int outDegree;  
    public int degree;  
    public int topNum;  
    public int dist;  
    public int primDist;  
    public int weight;  
    public Vertex(AnyType data,Arc firstArc){  
        this.data=data;  
        this.firstArc=firstArc;  
    }  
    public Vertex(AnyType data){  
        this(data,null);  
    }  
} 